package vo;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import utils.LocalDateDeserializer;
import utils.LocalDateSerializer;

@Entity
@Table(name="ocorrencias")
public class OcorrenciaVO implements Serializable{

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id_ocorrencia")
	private Integer id_ocorrencia;
	
	@OneToOne (fetch = FetchType.EAGER)
	@JoinColumn(name="id_motivo")
	private MotivoVO id_motivo;
	
	@OneToOne (fetch = FetchType.EAGER)
	@JoinColumn(name="id_departamento")
	private DepartamentoVO id_departamento;
	
	@Column(name="descricao")
	private String descricao;
	
	@JsonSerialize(using = LocalDateSerializer.class)
	@JsonDeserialize(using = LocalDateDeserializer.class)
	@Column(name="data_fato")
	private LocalDate data_fato;
	
	@Column(name="responsavel")
	private String responsavel;
	
	@Column(name="status")
	private Integer status;
	
	@OneToOne (fetch = FetchType.EAGER)
	@JoinColumns({
		@JoinColumn(name="codemp", referencedColumnName="codemp"),
		@JoinColumn(name="numped", referencedColumnName="numped"),
		@JoinColumn(name="numnfv", referencedColumnName="numnfv")
	})
	private E140NFV_VO notaFiscalVenda;
	
	@Transient
	private List<OcorrenciaItemVO> itemOcorrencia;
	
//
//	@OneToMany(mappedBy="id_ocorrencia")
//	private List<ProvidenciaVO> id_providencia;
//	
//	@OneToMany(mappedBy="id_ocorrencia")
//	private List<OcorrenciaProdutoVO> id_ocorrencia_produto;

	public Integer getId_ocorrencia() {
		return id_ocorrencia;
	}

	public void setId_ocorrencia(Integer id_ocorrencia) {
		this.id_ocorrencia = id_ocorrencia;
	}

	public MotivoVO getId_motivo() {
		return id_motivo;
	}

	public void setId_motivo(MotivoVO id_motivo) {
		this.id_motivo = id_motivo;
	}

	public DepartamentoVO getId_departamento() {
		return id_departamento;
	}

	public void setId_departamento(DepartamentoVO id_departamento) {
		this.id_departamento = id_departamento;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public LocalDate getData_fato() {
		return data_fato;
	}

	public void setData_fato(LocalDate data_fato) {
		this.data_fato = data_fato;
	}

	public String getResponsavel() {
		return responsavel;
	}

	public void setResponsavel(String responsavel) {
		this.responsavel = responsavel;
	}

	public E140NFV_VO getNotaFiscalVenda() {
		return notaFiscalVenda;
	}

	public void setNotaFiscalVenda(E140NFV_VO notaFiscalVenda) {
		this.notaFiscalVenda = notaFiscalVenda;
	}
//
//	public List<ProvidenciaVO> getId_providencia() {
//		return id_providencia;
//	}
//
//	public void setId_providencia(List<ProvidenciaVO> id_providencia) {
//		this.id_providencia = id_providencia;
//	}
//
//	public List<OcorrenciaProdutoVO> getId_ocorrencia_produto() {
//		return id_ocorrencia_produto;
//	}
//
//	public void setId_ocorrencia_produto(List<OcorrenciaProdutoVO> id_ocorrencia_produto) {
//		this.id_ocorrencia_produto = id_ocorrencia_produto;
//	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public List<OcorrenciaItemVO> getItem() {
		return itemOcorrencia;
	}

	public void setItem(List<OcorrenciaItemVO> item) {
		this.itemOcorrencia = item;
	}

	
	
	
}

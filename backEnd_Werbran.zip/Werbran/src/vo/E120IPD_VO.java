package vo;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="e120ipd")
public class E120IPD_VO implements Serializable {


	private static final long serialVersionUID = 508838465800575020L;

	@EmbeddedId
	private E120IPD_PK id;
	
	@OneToOne
	@JoinColumns({
		@JoinColumn(name="codpro", referencedColumnName="codpro", insertable=false, updatable=false, nullable=false),
		@JoinColumn(name="codempped" , referencedColumnName="codemppro", insertable=false, updatable=false, nullable=false)
	})
	private E075PRO_VO produto;
	
	@Column(name="tnspro")
	private String tnspro;
	
	@Column(name="qtdped")
	private Double qtdped;
	
	@Column(name="qtdpoc")
	private Double qtdpoc;
	
	@Column(name="qtdfat")
	private Double qtdfat;
	
	@Column(name="qtdcan")
	private Double qtdcan;
	
	@Column(name="unimed")
	private String unimed;
	
	@Column(name="preuni")
	private Double preuni;
	
	@Column(name="stsoco")
	private boolean stsoco;



	public boolean isStsoco() {
		return stsoco;
	}

	public void setStsoco(boolean stsoco) {
		this.stsoco = stsoco;
	}

	public E075PRO_VO getProduto() {
		return produto;
	}

	public void setProduto(E075PRO_VO produto) {
		this.produto = produto;
	}


	public E120IPD_PK getId() {
		return id;
	}

	public void setId(E120IPD_PK id) {
		this.id = id;
	}

	public String getTnspro() {
		return tnspro;
	}

	public void setTnspro(String tnspro) {
		this.tnspro = tnspro;
	}

	public Double getQtdped() {
		return qtdped;
	}

	public void setQtdped(Double qtdped) {
		this.qtdped = qtdped;
	}

	public Double getQtdpoc() {
		return qtdpoc;
	}

	public void setQtdpoc(Double qtdpoc) {
		this.qtdpoc = qtdpoc;
	}

	public Double getQtdfat() {
		return qtdfat;
	}

	public void setQtdfat(Double qtdfat) {
		this.qtdfat = qtdfat;
	}

	public Double getQtdcan() {
		return qtdcan;
	}

	public void setQtdcan(Double qtdcan) {
		this.qtdcan = qtdcan;
	}

	public String getUnimed() {
		return unimed;
	}

	public void setUnimed(String unimed) {
		this.unimed = unimed;
	}

	public Double getPreuni() {
		return preuni;
	}

	public void setPreuni(Double preuni) {
		this.preuni = preuni;
	}	
}

package vo;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="e090rep")
public class E090REP_VO implements Serializable{
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="codrep")
	private Integer codrep;
	
	@Column(name="nomerep")
	private String nomerep;

	public Integer getCodrep() {
		return codrep;
	}

	public void setCodrep(Integer codrep) {
		this.codrep = codrep;
	}

	public String getNomerep() {
		return nomerep;
	}

	public void setNomerep(String nomerep) {
		this.nomerep = nomerep;
	}

}

package vo;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.OneToOne;

@Embeddable
public class E140NFV_PK implements Serializable{

	@Column(name="numnfv")
	private Integer numnfv;
	
	
	@OneToOne
	@JoinColumns({
		@JoinColumn(name="codemp", referencedColumnName="codempped", insertable=false, updatable=false),
		@JoinColumn(name="numped", referencedColumnName="numped", insertable=false, updatable=false)
	})
	private E120PED_VO pedido;
	
	

	public Integer getNumnfv() {
		return numnfv;
	}

	public void setNumnfv(Integer numnfv) {
		this.numnfv = numnfv;
	}



	public E120PED_VO getPedido() {
		return pedido;
	}

	public void setPedido(E120PED_VO pedido) {
		this.pedido = pedido;
	}
	
	
	
}

package vo;

import java.io.Serializable;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="e140nfv")
public class E140NFV_VO implements Serializable{

	@EmbeddedId
	private E140NFV_PK id;
	
	public E140NFV_PK getId() {
		return id;
	}
	
	public void setId(E140NFV_PK id) {
		this.id = id;
	}
	
}

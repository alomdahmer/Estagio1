package vo;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="e075pro")
public class E075PRO_VO  implements Serializable{

	@EmbeddedId
	private E075PRO_PK id;
	
	@Column(name="despro")
	private String despro;
	
	@Column(name="unimed")
	private String unimed;
	
	@Column(name="unime2")
	private String unime2;
	
	@Column(name="unime3")
	private String unime3;

	public E075PRO_PK getId() {
		return id;
	}
	
	public void setId(E075PRO_PK id) {
		this.id = id;
	}

	public String getDespro() {
		return despro;
	}

	public void setDespro(String despro) {
		this.despro = despro;
	}

	public String getUnimed() {
		return unimed;
	}

	public void setUnimed(String unimed) {
		this.unimed = unimed;
	}

	public String getUnime2() {
		return unime2;
	}

	public void setUnime2(String unime2) {
		this.unime2 = unime2;
	}

	public String getUnime3() {
		return unime3;
	}

	public void setUnime3(String unime3) {
		this.unime3 = unime3;
	}
}

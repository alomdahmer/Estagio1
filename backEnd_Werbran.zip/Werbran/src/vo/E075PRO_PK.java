package vo;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class E075PRO_PK implements Serializable {

	@Column(name="codpro")
	private String codpro;
	
	@Column(name="codemppro")
	private Integer codemppro;

	public String getCodpro() {
		return codpro;
	}

	public void setCodpro(String codpro) {
		this.codpro = codpro;
	}

	public Integer getCodemppro() {
		return codemppro;
	}

	public void setCodemppro(Integer codemppro) {
		this.codemppro = codemppro;
	}
	
}

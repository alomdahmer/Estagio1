package vo;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="e085cli")
public class E085CLI_VO implements Serializable {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="codcli")
	private Integer codcli;
	
	@Column(name="nomcli")
	private String nomcli;
	
	@Column(name="apecli")
	private String apecli;
	
	@Column(name="marcli")
	private String marcli;
	
	@Column(name="codram")
	private String codram;
	
	@Column(name="cgccpf")
	private String cgccpf;
	
	@Column(name="endcli")
	private String endcli;
	
	@Column(name="cplend")
	private String cplend;
	
	@Column(name="baicli")
	private String baicli;
	
	@Column(name="cidcli")
	private String cidcli;
	
	@Column(name="sigufs")
	private String sigufs;
	
	@Column(name="foncli")
	private String foncli;
	
	@Column(name="sitcli")
	private String sitcli;

	public Integer getCodcli() {
		return codcli;
	}

	public void setCodcli(Integer codcli) {
		this.codcli = codcli;
	}

	public String getNomcli() {
		return nomcli;
	}

	public void setNomcli(String nomcli) {
		this.nomcli = nomcli;
	}

	public String getApecli() {
		return apecli;
	}

	public void setApecli(String apecli) {
		this.apecli = apecli;
	}

	public String getMarcli() {
		return marcli;
	}

	public void setMarcli(String marcli) {
		this.marcli = marcli;
	}

	public String getCodram() {
		return codram;
	}

	public void setCodram(String codram) {
		this.codram = codram;
	}

	public String getCgccpf() {
		return cgccpf;
	}

	public void setCgccpf(String cgccpf) {
		this.cgccpf = cgccpf;
	}

	public String getEndcli() {
		return endcli;
	}

	public void setEndcli(String endcli) {
		this.endcli = endcli;
	}

	public String getCplend() {
		return cplend;
	}

	public void setCplend(String cplend) {
		this.cplend = cplend;
	}

	public String getBaicli() {
		return baicli;
	}

	public void setBaicli(String baicli) {
		this.baicli = baicli;
	}

	public String getCidcli() {
		return cidcli;
	}

	public void setCidcli(String cidcli) {
		this.cidcli = cidcli;
	}

	public String getSigufs() {
		return sigufs;
	}

	public void setSigufs(String sigufs) {
		this.sigufs = sigufs;
	}

	public String getFoncli() {
		return foncli;
	}

	public void setFoncli(String foncli) {
		this.foncli = foncli;
	}

	public String getSitcli() {
		return sitcli;
	}

	public void setSitcli(String sitcli) {
		this.sitcli = sitcli;
	}
	
}


package vo;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import utils.LocalDateDeserializer;
import utils.LocalDateSerializer;

@Entity
@Table(name="e120ped")
public class E120PED_VO implements Serializable{

	@EmbeddedId
	private E120PED_PK id;
	
	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name="codcli")
	private E085CLI_VO cliente;
	
	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name="codrep")
	private E090REP_VO representante;
	
	@Column(name="datemi")
	@JsonSerialize(using = LocalDateSerializer.class)
	@JsonDeserialize(using = LocalDateDeserializer.class)
	private LocalDate datemi;
	
	@Column(name="horemi")
	private Integer horemi;
	
	@Column(name="vlrbru")
	private Double vlrbru;
	

	@OneToMany(fetch = FetchType.EAGER)
	@JoinColumns({	
		@JoinColumn(name="numped",referencedColumnName="numped"),
		@JoinColumn(name="codempped",referencedColumnName="codempped")
	})
	private List<E120IPD_VO> itemPedido;


	public E120PED_PK getId() {
		return id;
	}

	public void setId(E120PED_PK id) {
		this.id = id;
	}

	public E085CLI_VO getCliente() {
		return cliente;
	}

	public void setCliente(E085CLI_VO cliente) {
		this.cliente = cliente;
	}

	public E090REP_VO getRepresentante() {
		return representante;
	}

	public void setRepresentante(E090REP_VO representante) {
		this.representante = representante;
	}

	public LocalDate getDatemi() {
		return datemi;
	}

	public void setDatemi(LocalDate datemi) {
		this.datemi = datemi;
	}

	public Integer getHoremi() {
		return horemi;
	}

	public void setHoremi(Integer horemi) {
		this.horemi = horemi;
	}

	public Double getVlrbru() {
		return vlrbru;
	}

	public void setVlrbru(Double vlrbru) {
		this.vlrbru = vlrbru;
	}

	public List<E120IPD_VO> getItemPedido() {
		return itemPedido;
	}

	public void setItemPedido(List<E120IPD_VO> itemPedido) {
		this.itemPedido = itemPedido;
	}
	
	
	
}
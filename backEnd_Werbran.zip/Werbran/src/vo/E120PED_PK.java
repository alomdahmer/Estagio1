package vo;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class E120PED_PK implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1499166367040500881L;

	@Column(name="numped")
	private Integer numped;
	
	@Column(name="codempped")
	private Integer codempped;

	public Integer getNumped() {
		return numped;
	}

	public void setNumped(Integer numped) {
		this.numped = numped;
	}

	public Integer getCodempped() {
		return codempped;
	}

	public void setCodempped(Integer codempped) {
		this.codempped = codempped;
	}
}
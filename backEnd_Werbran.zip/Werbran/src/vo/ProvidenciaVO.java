package vo;

import java.io.Serializable;
import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import utils.LocalDateDeserializer;
import utils.LocalDateSerializer;

@Entity
@Table(name="providencias")
public class ProvidenciaVO implements Serializable{

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id_providencia")
	private Integer id_providencia;
	
	@ManyToOne
	@JoinColumn(name="id_ocorrencia")
	private OcorrenciaVO id_ocorrencia;
	
	@Column(name="acao")
	private String acao;
	
	@JsonSerialize(using = LocalDateSerializer.class)
	@JsonDeserialize(using = LocalDateDeserializer.class)
	@Column(name="data")
	private LocalDate data;

	public Integer getId_providencia() {
		return id_providencia;
	}

	public void setId_providencia(Integer id_providencia) {
		this.id_providencia = id_providencia;
	}

	public OcorrenciaVO getId_ocorrencia() {
		return id_ocorrencia;
	}

	public void setId_ocorrencia(OcorrenciaVO id_ocorrencia) {
		this.id_ocorrencia = id_ocorrencia;
	}

	public String getAcao() {
		return acao;
	}

	public void setAcao(String acao) {
		this.acao = acao;
	}

	public LocalDate getData() {
		return data;
	}

	public void setData(LocalDate data) {
		this.data = data;
	}

	
}

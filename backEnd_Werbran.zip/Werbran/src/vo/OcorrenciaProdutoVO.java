package vo;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="tb_ocorrencia_produto")
public class OcorrenciaProdutoVO implements Serializable{

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id_ocorrencia_produto")
	private Integer id_ocorrencia_produto;
	
	@ManyToOne
	@JoinColumn(name="id_ocorrencia")
	private OcorrenciaVO id_ocorrencia;
	
	//@OneToOne
	//@JoinColumns({
	//	@JoinColumn(name="seqipd"),
	//	@JoinColumn(name="numped"),
	//	@JoinColumn(name="codemp")
	//})
	@OneToOne
	@JoinColumns({
		@JoinColumn(name="seqipd"),
		@JoinColumn(name="numped"),
		@JoinColumn(name="codempped")
	})
	private E120IPD_VO itemPedido;
	
	
	
}

package vo;

import java.io.Serializable;
import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import utils.LocalDateDeserializer;
import utils.LocalDateSerializer;

@Entity
@Table(name="motivo")
public class MotivoVO implements Serializable{
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id_motivo")
	private Integer id_motivo;
	
	@Column(name="tipo_motivo")
	private Integer tipo_motivo;
	
	@Column(name="descMotivo")
	private String descMotivo;
	
	@Transient
	private Integer total;
	
	@JsonSerialize(using = LocalDateSerializer.class)
	@JsonDeserialize(using = LocalDateDeserializer.class)
	@Transient
	private LocalDate dataInicio;
	
	@JsonSerialize(using = LocalDateSerializer.class)
	@JsonDeserialize(using = LocalDateDeserializer.class)
	@Transient
	private LocalDate dataFim;
	

	public LocalDate getDataInicio() {
		return dataInicio;
	}

	public void setDataInicio(LocalDate dataInicio) {
		this.dataInicio = dataInicio;
	}

	public LocalDate getDataFim() {
		return dataFim;
	}

	public void setDataFim(LocalDate dataFim) {
		this.dataFim = dataFim;
	}

	public Integer getTotal() {
		return total;
	}

	public void setTotal(Integer total) {
		this.total = total;
	}

	public Integer getId_motivo() {
		return id_motivo;
	}

	public void setId_motivo(Integer id_motivo) {
		this.id_motivo = id_motivo;
	}

	public Integer getTipo_motivo() {
		return tipo_motivo;
	}

	public void setTipo_motivo(Integer tipo_motivo) {
		this.tipo_motivo = tipo_motivo;
	}

	public String getDescMotivo() {
		return descMotivo;
	}

	public void setDescMotivo(String descMotivo) {
		this.descMotivo = descMotivo;
	}
	
	
}

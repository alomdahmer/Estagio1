package vo;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class E120IPD_PK implements Serializable {

	@Column(name="seqipd")
	private Integer seqipd;
	
	@Column(name="numped")
	private Integer numped;
	
	@Column(name="codempped")
	private Integer codempped;

	public Integer getSeqipd() {
		return seqipd;
	}

	public void setSeqipd(Integer seqipd) {
		this.seqipd = seqipd;
	}

	public Integer getNumped() {
		return numped;
	}

	public void setNumped(Integer numped) {
		this.numped = numped;
	}

	public Integer getCodempped() {
		return codempped;
	}

	public void setCodempped(Integer codempped) {
		this.codempped = codempped;
	}


}

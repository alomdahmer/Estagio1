package ws;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import br.edu.unisep.hibernate.HibernateSessionFactory;
import vo.DepartamentoVO;
import vo.E120IPD_VO;
import vo.E140NFV_VO;
import vo.MotivoVO;
import vo.OcorrenciaItemVO;
import vo.OcorrenciaVO;
import vo.ProvidenciaVO;
import ws.WSGenerico;


	@Path("/ocorrencia")
	public class OcorrenciaWS extends WSGenerico<OcorrenciaVO> {

		public OcorrenciaWS() {
			super(OcorrenciaVO.class);
		}
		
		
		@GET
		@Path("/listarMotivos")
		@Produces(MediaType.APPLICATION_JSON)
		public List<MotivoVO> listarMotivos() {
			Session session = HibernateSessionFactory.getSession();
			Query<MotivoVO> q = session.createQuery("from MotivoVO", MotivoVO.class);
			List<MotivoVO> resultado = q.list();
			session.close();
			return resultado;
		}
		
		@GET
		@Path("/listarDepartamentos")
		@Produces(MediaType.APPLICATION_JSON)
		public List<DepartamentoVO> listarDepartamentos() {
			Session session = HibernateSessionFactory.getSession();
			Query<DepartamentoVO> q = session.createQuery("from DepartamentoVO", DepartamentoVO.class);
			List<DepartamentoVO> resultado = q.list();
			session.close();
			return resultado;
		}
		
		
		@GET
		@Path("/listarOrdenado")
		@Produces(MediaType.APPLICATION_JSON)
		public List<OcorrenciaVO> listarOrdenado() {
			Session session = HibernateSessionFactory.getSession();
			Query<OcorrenciaVO> q = session.createQuery("from OcorrenciaVO order by nome", OcorrenciaVO.class);
			List<OcorrenciaVO> resultado = q.list();
			session.close();
			return resultado;
		}
		
		@GET
		@Path("/listaEmAberto")
		@Produces(MediaType.APPLICATION_JSON)
		public List<OcorrenciaVO> listaEmAberto(){
			Session session = HibernateSessionFactory.getSession();
			Query<OcorrenciaVO> q = session.createQuery("from OcorrenciaVO where status = 1 order by data_fato", OcorrenciaVO.class);
			List<OcorrenciaVO> lista = q.list();
			session.close();
			return lista;
		}
		
		@GET
		@Path("/contaEmAnalise")
		@Produces(MediaType.APPLICATION_JSON)
		public Integer contaEmAnalise(){
			Session session = HibernateSessionFactory.getSession();
			Query<Long> q = session.createQuery("select count (*) from OcorrenciaVO where status = 2", Long.class);
			Long lista = q.uniqueResult();
			session.close();
			return lista.intValue();
		}
		
		@GET
		@Path("/contaTodas")
		@Produces(MediaType.APPLICATION_JSON)
		public Integer contaTodas(){
			Session session = HibernateSessionFactory.getSession();
			Query<Long> q = session.createQuery("select count(*) from OcorrenciaVO", Long.class);
			Long lista = q.uniqueResult();
			session.close();
			return lista.intValue();
		}
		
		@GET
		@Path("/contaEmAberto")
		@Produces(MediaType.APPLICATION_JSON)
		public Integer contaEmAberto(){
			Session session = HibernateSessionFactory.getSession();
			Query<Long> q = session.createQuery("select count (*) from OcorrenciaVO where status = 1", Long.class);
			Long lista = q.uniqueResult();
			session.close();
			return lista.intValue();
		}
		
		
		@GET
		@Path("/contaFechadas")
		@Produces(MediaType.APPLICATION_JSON)
		public Integer contaFechadas(){
			Session session = HibernateSessionFactory.getSession();
			Query<Long> q = session.createQuery("select count (*) from OcorrenciaVO where status = 3", Long.class);
			Long lista = q.uniqueResult();
			session.close();
			return lista.intValue();
		}
		
		@POST
		@Path("/consultaNumeroNota")
		@Produces(MediaType.APPLICATION_JSON)
		public E140NFV_VO consultaNumeroNota(Integer id){
			
			Session session = HibernateSessionFactory.getSession();
	
			StringBuffer sb = new StringBuffer();
			sb.append("from E140NFV_VO e where e.id.numnfv = :id ");
		
			Query<E140NFV_VO> q = session.createQuery(sb.toString(), E140NFV_VO.class);
			q.setParameter("id", id);
			E140NFV_VO lista = q.uniqueResult();
			session.close();
			return lista;
		}
		
		@POST
		@Path("/consultaNumeroPedido")
		@Produces(MediaType.APPLICATION_JSON)
		public E140NFV_VO consultaNumeroPedido(Integer id){
			Session session = HibernateSessionFactory.getSession();
			
			StringBuffer sb = new StringBuffer();
			sb.append("from E140NFV_VO e where e.id.pedido.id.numped = :id ");
			sb.append(" AND e.id.pedido.id.codempped = 1");
			
			Query<E140NFV_VO> q = session.createQuery(sb.toString(), E140NFV_VO.class);
			q.setParameter("id", id);
			
			E140NFV_VO lista = q.uniqueResult();
			session.close();
			return lista;
		}
		
		@POST
		@Path("/consultaIdOcorrencia")
		@Produces(MediaType.APPLICATION_JSON)
		public OcorrenciaVO consultaIdOcorrencia(Integer id){
			Session session = HibernateSessionFactory.getSession();
			Query<OcorrenciaVO> q = session.createQuery("from OcorrenciaVO where id_ocorrencia = :id", OcorrenciaVO.class);
			q.setParameter("id", id);
			OcorrenciaVO ocorrencia =  q.uniqueResult();
			session.close();
			return ocorrencia;
		}
		
		@POST
		@Path("/consultaListaOcorrencias")
		@Produces(MediaType.APPLICATION_JSON)
		public List<OcorrenciaVO> consultaListaOcorrencias(Integer id){
			Session session = HibernateSessionFactory.getSession();
			Query<OcorrenciaVO> q = session.createQuery("from OcorrenciaVO where id_ocorrencia = :id", OcorrenciaVO.class);
			q.setParameter("id", id);
			List<OcorrenciaVO> ocorrencia =  q.list();
			session.close();
			return ocorrencia;
		}
		
		
		@POST
		@Path("/consultaProvidencias")
		@Produces(MediaType.APPLICATION_JSON)
		public List<ProvidenciaVO> consultaProvidencias(Integer id){
			Session session = HibernateSessionFactory.getSession();
			Query<ProvidenciaVO> q = session.createQuery("from ProvidenciaVO where id_ocorrencia.id_ocorrencia = :id", ProvidenciaVO.class);
			q.setParameter("id", id);
			List<ProvidenciaVO> lista = q.list();
			session.close();
			return lista;
		}
		
		@POST
		@Path("/atualizarOcorrencia")
		@Produces(MediaType.APPLICATION_JSON)
		public void atualizarOcorrencia(OcorrenciaVO ocorrencia){
			Session session = HibernateSessionFactory.getSession();
			Transaction trans = session.beginTransaction();
			session.update(ocorrencia);
			trans.commit();
			session.close();
		}
		
		@POST
		@Path("/salvarProvidencia")
		@Produces(MediaType.APPLICATION_JSON)
		public void salvarOcorrencia(ProvidenciaVO providencia){
			Session session = HibernateSessionFactory.getSession();
			Transaction trans = session.beginTransaction();
			session.save(providencia);
			trans.commit();
			session.close();
		}
		
		
		@POST
		@Path("/salvarOcorrencia")
		@Produces(MediaType.APPLICATION_JSON)
		public void salvarOcorrencia(OcorrenciaVO ocorrencia){
			Session session = HibernateSessionFactory.getSession();
			Transaction trans = session.beginTransaction();
			session.save(ocorrencia);
			
			for ( E120IPD_VO itemPedido : ocorrencia.getNotaFiscalVenda().getId().getPedido().getItemPedido()) {
				
				if(itemPedido.isStsoco()) {
					
					OcorrenciaItemVO itemOcorrencia = new OcorrenciaItemVO();
					itemOcorrencia.setIdOcorrencia(ocorrencia.getId_ocorrencia());
					itemOcorrencia.setItem(itemPedido.getId().getSeqipd());
					session.save(itemOcorrencia);
				}
			}
			
			trans.commit();
			session.close();
		}
		
		
		@POST
		@Path("/relatorioOcorrencias")
		@Produces(MediaType.APPLICATION_JSON)
		public List<Object> relatorioOcorrencias(MotivoVO motivo){
			Session session = HibernateSessionFactory.getSession();
			
			StringBuffer sb = new StringBuffer();
			sb.append("select m.tipo_motivo, count(*) as total from motivo m");
			sb.append(" inner join ocorrencias o");
			sb.append(" on m.id_motivo = o.id_motivo");
			sb.append(" where o.data_fato >= :dataInicio and o.data_fato <= :dataFim");
			sb.append(" group by m.tipo_motivo");
			
			Query q = session.createNativeQuery(sb.toString());
			q.setParameter("dataInicio", motivo.getDataInicio());
			q.setParameter("dataFim", motivo.getDataFim());
			List<Object> lista = q.list();
			session.close();
			return lista;
		}
		
}

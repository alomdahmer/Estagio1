package br.edu.unisep.serializer;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;

public class LocalDateDeserializer extends JsonDeserializer<LocalDate> {

	@Override
	public LocalDate deserialize(JsonParser jp, DeserializationContext dc)
			throws IOException, JsonProcessingException {

		LocalDate dt = null;
		DateTimeFormatter formatter;

		String strDt = jp.getText();

		try {
			formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
			dt = LocalDate.parse(strDt, formatter);
		} catch (Exception e) {
			
			try {
				formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
				dt = LocalDate.parse(strDt, formatter);
			} catch (Exception ex) {
				ex.printStackTrace();
			}			
			
		}

		return dt;
	}
}

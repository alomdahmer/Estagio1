package br.edu.unisep.hibernate;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

public class HibernateDAO<T> {

	public List<T> listar(Class<T> classe) {
		
		Session session = HibernateSessionFactory.getSession();
		
		Query<T> q = session.createQuery("from " + classe.getName(), classe);
		List<T> resultado = q.list();
		
		session.close();
		
		return resultado;
	}
	
	public void salvar(T obj) {
		Session session = HibernateSessionFactory.getSession();
		Transaction trans = session.beginTransaction();
		
		try {
			session.save(obj);
			trans.commit();
		} catch (Exception e) {
			trans.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
	}
	
	public void alterar(T obj) {
		Session session = HibernateSessionFactory.getSession();
		Transaction trans = session.beginTransaction();
		
		try {
			session.update(obj);
			trans.commit();
		} catch (Exception e) {
			trans.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
	}
	
	public void excluir(T obj) {
		Session session = HibernateSessionFactory.getSession();
		Transaction trans = session.beginTransaction();
		
		try {
			session.delete(obj);
			trans.commit();
		} catch (Exception e) {
			trans.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
	}
	
	public T consultar(Integer id, Class<T> classe) {
		Session session = HibernateSessionFactory.getSession();
		
		Query<T> q = session.createQuery("from " + classe.getName() + " where id = :ID", classe);
		q.setParameter("ID", id);
		
		T resultado = q.uniqueResult();
		
		session.close();
		
		return resultado;
	}
	
}
